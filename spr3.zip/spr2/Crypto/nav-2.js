function navSlide() {
    const burger = document.querySelector(".burger");
    const navjs = document.querySelector(".nav-links-2");
    const anijs = document.querySelectorAll(".nav-links-2 li");
    
    
    burger.addEventListener("click", () => {
        //Toggle Nav
        navjs.classList.toggle("nav-active-2");
        
        //Animate Links
        anijs.forEach((link, index) => {
            if (link.style.animation) {
                link.style.animation = ""
            } else {
                link.style.animation = `anijsFade 0.5s ease forwards ${index / 7 + 0.5}s`;
            }
        });
        //Burger Animation
        burger.classList.toggle("toggle");
    });
    
}

navSlide();

